import { Container } from "react-bootstrap";

export default function Preloader(){
    return (
        <Container>
            
        </Container>
    )
}